
DATABASE_HOST = 'mgdb.csjdzcwr1lpk.us-east-1.rds.amazonaws.com'
DATABASE_USERNAME = 'mgdbun'
DATABASE_PASSWORD = 'MaccabiGames'
